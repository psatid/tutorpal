import { useEffect, useRef, type ReactNode } from 'react'
import { useNavigate } from '@tanstack/react-router'
import tutorObjects from '../assets/prototype/tutor-objects.png'
import tutorWorkspace from '../assets/prototype/tutor-workspace.png'
import './cinematic-prototype.css'
import { useMarketingLanguage } from './marketing-language'

// Throwaway homepage explorations: three variants on /?variant=A|B|C, available only in development.
export type CinematicPrototypeVariant = 'A' | 'B' | 'C'

const variants = {
  A: { name: 'The Day Begins Clear' },
  B: { name: 'Everything in Reach' },
  C: { name: 'The Teaching Rhythm' },
} satisfies Record<CinematicPrototypeVariant, { name: string }>

function usePrototypeCopy() {
  const { language, copy } = useMarketingLanguage()
  const thai = language === 'th'
  return {
    language,
    copy,
    thai,
    label: thai ? 'ตัวอย่าง TutorPal' : 'Illustrative TutorPal preview',
    lesson: 'English foundations',
    learner: 'Maya Chen',
  }
}

function usePrototypeReveal<T extends HTMLElement = HTMLElement>(
  rootMargin = '0px 0px -12% 0px',
) {
  const sceneRef = useRef<T>(null)

  useEffect(() => {
    const scene = sceneRef.current
    if (!scene) return

    if (
      window.matchMedia('(prefers-reduced-motion: reduce)').matches ||
      !('IntersectionObserver' in window)
    ) {
      scene.classList.add('is-revealed')
      return
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return
        scene.classList.add('is-revealed')
        observer.disconnect()
      },
      { threshold: 0, rootMargin },
    )

    observer.observe(scene)
    return () => observer.disconnect()
  }, [])

  return sceneRef
}

function PrototypeHeader() {
  const { language, toggleLanguage } = useMarketingLanguage()
  const thai = language === 'th'
  const portalUrl = import.meta.env.PUBLIC_PORTAL_URL
  return (
    <header className="prototype-header">
      <a
        className="wordmark"
        href="#prototype-top"
        aria-label={thai ? 'หน้าแรกต้นแบบ TutorPal' : 'TutorPal prototype home'}
      >
        <span aria-hidden="true" className="wordmark-mark">
          T
        </span>
        TutorPal
      </a>
      <nav aria-label={thai ? 'เมนูต้นแบบ' : 'Prototype navigation'}>
        <a href="#product">{thai ? 'ผลิตภัณฑ์' : 'Product'}</a>
        <a href="#workflow">{thai ? 'วิธีทำงาน' : 'Workflow'}</a>
        <a href="#beta">{thai ? 'เบต้า' : 'Beta'}</a>
        <a className="prototype-header-cta" href="#workflow">
          {thai ? 'สำรวจ' : 'Explore'}
        </a>
        <button
          className="prototype-language"
          type="button"
          onClick={toggleLanguage}
        >
          {thai ? 'English' : 'ไทย'}
        </button>
        {portalUrl ? (
          <a className="prototype-portal-link" href={portalUrl}>
            {thai ? 'เข้าสู่พอร์ทัล' : 'Portal login'}
          </a>
        ) : null}
      </nav>
    </header>
  )
}

function PreviewCaption() {
  const { label } = usePrototypeCopy()
  return <figcaption>{label}</figcaption>
}

function BalancePanel({ compact = false }: { compact?: boolean }) {
  const { thai, lesson, learner } = usePrototypeCopy()
  return (
    <figure
      className={`product-panel balance-panel${compact ? ' is-compact' : ''}`}
    >
      <div className="panel-topline">
        <span>{thai ? 'คลาส' : 'Class'}</span>
        <span className="panel-dot" />
      </div>
      <div className="class-person">
        <span className="avatar" aria-hidden="true">
          M
        </span>
        <div>
          <strong>{lesson}</strong>
          <span>{learner}</span>
        </div>
      </div>
      <div className="member-chips">
        <span>{thai ? 'นักเรียน' : 'Student'}</span>
        <span>{thai ? 'รายบุคคล' : 'Individual'}</span>
      </div>
      <div className="balance-box">
        <span>{thai ? 'ชั่วโมงคงเหลือ' : 'Remaining hours'}</span>
        <strong>
          7.0 <small>/ 10.0 h</small>
        </strong>
        <div className="balance-progress">
          <i />
        </div>
        <p>{thai ? 'รายได้ที่บันทึกแล้ว ฿2,400' : 'Recorded revenue ฿2,400'}</p>
      </div>
      <PreviewCaption />
    </figure>
  )
}

function TodayPanel({ completed = false }: { completed?: boolean }) {
  const { thai, lesson } = usePrototypeCopy()
  return (
    <figure className="product-panel today-panel">
      <div className="panel-appbar">
        <span className="mini-logo">T</span>
        <strong>{thai ? 'หน้าหลัก' : 'Home'}</strong>
        <span>{thai ? 'ไทย' : 'English'}</span>
      </div>
      <div className="today-title">
        <span>{thai ? 'วันอาทิตย์ 16 สิงหาคม' : 'Sunday, August 16'}</span>
        <h3>{thai ? 'วันนี้' : 'Today'}</h3>
        <p>
          {thai ? 'เซสชันและงานที่รออยู่' : 'Your sessions and the work ahead.'}
        </p>
      </div>
      <div className="agenda-row">
        <span>09:00</span>
        <div>
          <strong>{lesson}</strong>
          <small>{thai ? 'ออนไลน์ · 1 ชม.' : 'Online · 1 h'}</small>
        </div>
        <em>
          {completed
            ? thai
              ? 'เสร็จสิ้น'
              : 'Completed'
            : thai
              ? 'ตามตาราง'
              : 'Scheduled'}
        </em>
      </div>
      <div className={`confirm-box${completed ? ' is-completed' : ''}`}>
        <span>
          {completed
            ? thai
              ? 'เซสชันล่าสุด'
              : 'Recent session'
            : thai
              ? 'เซสชันที่ต้องยืนยัน'
              : 'Session to confirm'}
        </span>
        <strong>{lesson}</strong>
        <p>09:00 – 10:00</p>
        <div aria-hidden="true">
          {completed ? (
            <span>{thai ? 'เสร็จสิ้น' : 'Completed'}</span>
          ) : (
            <>
              <span>{thai ? 'ทำเสร็จ' : 'Complete'}</span>
              <span>{thai ? 'ไม่มา' : 'No show'}</span>
            </>
          )}
        </div>
      </div>
      <PreviewCaption />
    </figure>
  )
}

function WeekPanel({ ruler = false }: { ruler?: boolean }) {
  const { thai, lesson } = usePrototypeCopy()
  return (
    <figure className={`product-panel week-panel${ruler ? ' is-ruler' : ''}`}>
      <div className="week-head">
        <strong>{thai ? 'ตารางเรียน' : 'Schedules'}</strong>
        <span>{thai ? 'สัปดาห์' : 'Week'}</span>
      </div>
      <div className="date-tabs">
        <span>14</span>
        <span>15</span>
        <span className="is-selected">16</span>
        <span>17</span>
        <span>18</span>
      </div>
      <div className="week-grid">
        <span>09:00</span>
        <div className="session-block">
          <strong>{lesson}</strong>
          <small>{thai ? 'ออนไลน์ · 1 ชม.' : 'Online · 1 h'}</small>
        </div>
        <span>10:00</span>
        <span>11:00</span>
      </div>
      <PreviewCaption />
    </figure>
  )
}

function BWeekMaster() {
  const { thai, lesson } = usePrototypeCopy()
  return (
    <figure className="product-panel b-week-master">
      <div className="panel-appbar">
        <strong>{thai ? 'ตารางเรียน' : 'Schedules'}</strong>
        <span>{thai ? 'ไทย' : 'English'}</span>
      </div>
      <div className="b-week-toolbar" aria-hidden="true">
        <strong>{thai ? '10–16 ส.ค. 2026' : 'Aug 10–16, 2026'}</strong>
        <span>{thai ? 'วันนี้' : 'Today'}</span>
        <span>{thai ? 'วัน' : 'Day'}</span>
        <span className="is-selected">{thai ? 'สัปดาห์' : 'Week'}</span>
      </div>
      <div className="b-week-chips" aria-hidden="true">
        <span>{thai ? '3–9 ส.ค.' : 'Aug 3–9'}</span>
        <span className="is-selected">{thai ? '10–16 ส.ค.' : 'Aug 10–16'}</span>
        <span>{thai ? '17–23 ส.ค.' : 'Aug 17–23'}</span>
      </div>
      <div className="b-week-actions" aria-hidden="true">
        <span>{thai ? 'ค้นหาตามคลาส…' : 'Search by class…'}</span>
        <strong>+ {thai ? 'เพิ่มตาราง' : 'Add Schedule'}</strong>
      </div>
      <div className="b-week-filters" aria-hidden="true">
        <span className="is-selected">{thai ? 'ทั้งหมด' : 'All'}</span>
        <span>{thai ? 'ตามตาราง' : 'Scheduled'}</span>
        <span>{thai ? 'เสร็จสิ้น' : 'Completed'}</span>
        <span>{thai ? 'ไม่มา' : 'No Show'}</span>
        <span>{thai ? 'ยกเลิก' : 'Cancelled'}</span>
      </div>
      <div className="b-week-calendar">
        <div>
          <small>{thai ? 'ศ.' : 'FRI'}</small>
          <strong>14</strong>
        </div>
        <div>
          <small>{thai ? 'ส.' : 'SAT'}</small>
          <strong>15</strong>
        </div>
        <div className="is-today">
          <small>{thai ? 'อา.' : 'SUN'}</small>
          <strong>16</strong>
        </div>
        <span>09:00</span>
        <span>10:00</span>
        <span>11:00</span>
        <article>
          <strong>{lesson}</strong>
          <small>09:00–10:00 · {thai ? 'ออนไลน์' : 'Online'}</small>
        </article>
      </div>
      <span className="b-week-crop-note">
        {thai
          ? 'มุมมองสัปดาห์ · รายละเอียด ศ.–อา.'
          : 'Week view · Fri–Sun detail'}
      </span>
      <PreviewCaption />
    </figure>
  )
}

function BHybridBeat({
  index,
  title,
  copy,
  children,
}: {
  index: number
  title: string
  copy: string
  children: ReactNode
}) {
  const sceneRef = usePrototypeReveal<HTMLElement>()
  return (
    <article
      ref={sceneRef}
      className={`b-hybrid-beat b-hybrid-beat-${index} prototype-reveal`}
    >
      <div>
        <h2>{title}</h2>
        <p>{copy}</p>
      </div>
      {children}
    </article>
  )
}

function DayPanel() {
  const { thai, lesson } = usePrototypeCopy()
  return (
    <figure className="product-panel day-panel">
      <div className="week-head">
        <strong>{thai ? 'ตารางเรียน' : 'Schedules'}</strong>
        <span>{thai ? 'วัน' : 'Day'}</span>
      </div>
      <div className="day-date">
        <span>‹</span>
        <strong>{thai ? 'อาทิตย์ 16 ส.ค.' : 'Sun, Aug 16'}</strong>
        <span>›</span>
      </div>
      <div className="day-grid">
        <span>09:00</span>
        <div>
          <strong>{lesson}</strong>
          <small>{thai ? 'ออนไลน์ · 60 นาที' : 'Online · 60 min'}</small>
          <em>{thai ? 'ตามตาราง' : 'Scheduled'}</em>
        </div>
        <span>10:00</span>
      </div>
      <PreviewCaption />
    </figure>
  )
}

function PrototypeBetaStub() {
  const { copy, thai } = usePrototypeCopy()
  return (
    <section
      className="prototype-beta"
      id="beta"
      aria-labelledby="prototype-beta-title"
    >
      <div>
        <p className="prototype-marker">
          {thai ? 'ตัวอย่างเฉพาะเครื่องนี้' : 'LOCAL PROTOTYPE ONLY'}
        </p>
        <h2 id="prototype-beta-title">{copy.beta.title}</h2>
        <p>{copy.beta.description}</p>
      </div>
      <form
        className="prototype-beta-stub"
        onSubmit={(event) => event.preventDefault()}
        aria-label={thai ? 'ตัวอย่างแบบฟอร์มเบต้า' : 'Beta form preview'}
      >
        <div className="prototype-beta-fields">
          <label>
            {copy.beta.form.name}
            <input
              type="text"
              placeholder={thai ? 'ชื่อของคุณ' : 'Your name'}
            />
          </label>
          <label>
            {copy.beta.form.email}
            <input type="email" placeholder="you@example.com" />
          </label>
          <label>
            {copy.beta.form.subject}
            <input
              type="text"
              placeholder={thai ? 'เช่น ภาษาอังกฤษ' : 'e.g. English'}
            />
          </label>
          <label>
            {copy.beta.form.note} <span>{copy.beta.form.optional}</span>
            <textarea rows={2} />
          </label>
        </div>
        <label className="prototype-consent">
          <input type="checkbox" />
          <span>
            {copy.beta.form.consentBefore}{' '}
            <a href="/privacy">{copy.common.privacy}</a>
            {copy.beta.form.consentAfter}
          </span>
        </label>
        <button className="button" type="submit">
          {copy.beta.form.joinBeta}
        </button>
        <p>
          {thai
            ? 'ตัวอย่างในเครื่องเท่านั้น ไม่มีการส่งหรือบันทึกข้อมูล'
            : 'Local preview only. No submission or persistence.'}
        </p>
      </form>
    </section>
  )
}

function PrototypeFaq() {
  const { thai } = usePrototypeCopy()
  const questions = thai
    ? [
        [
          'TutorPal เหมาะกับใคร',
          'สำหรับครูสอนพิเศษอิสระที่อยากให้ตารางเรียน คลาส ชั่วโมง และนักเรียนอยู่ใกล้กัน',
        ],
        [
          'ช่วยเรื่องอะไรได้บ้าง',
          'เริ่มจากจัดคลาส เพิ่มชั่วโมง วางตาราง แล้วเห็นภาพของวันนี้และสัปดาห์ได้ในที่เดียว',
        ],
        [
          'ตอนนี้สมัครได้ไหม',
          'นี่คือหน้าแนวคิดสำหรับเครื่องนี้เท่านั้น แบบฟอร์มด้านบนจะไม่ส่งข้อมูล',
        ],
      ]
    : [
        [
          'Who is TutorPal for?',
          'Independent tutors who want their students, classes, teaching hours, and schedule to stay within reach.',
        ],
        [
          'What does it help with?',
          'Set up a class, add its hours, schedule the session, and see the same work through today and the week.',
        ],
        [
          'Can I sign up here?',
          'This local prototype keeps the beta area deliberately non-submitting.',
        ],
      ]
  return (
    <section
      className="prototype-faq"
      id="faq"
      aria-labelledby="prototype-faq-title"
    >
      <div>
        <h2 id="prototype-faq-title">
          {thai ? 'คำถามก่อนเริ่ม' : 'A few useful answers.'}
        </h2>
      </div>
      <div>
        {questions.map(([question, answer]) => (
          <details key={question}>
            <summary>
              {question}
              <span aria-hidden="true">+</span>
            </summary>
            <p>{answer}</p>
          </details>
        ))}
      </div>
    </section>
  )
}

function PrototypeFooter() {
  const { thai } = usePrototypeCopy()
  return (
    <footer className="prototype-footer">
      <span>© TutorPal</span>
      <span>
        {thai
          ? 'จัดการงานสำหรับครูสอนพิเศษอิสระอย่างสบายใจ'
          : 'Calm operations for independent tutors.'}
      </span>
      <a href="/privacy">{thai ? 'ประกาศความเป็นส่วนตัว' : 'Privacy notice'}</a>
    </footer>
  )
}

function DirectionA() {
  const { thai } = usePrototypeCopy()
  const heroRef = usePrototypeReveal()
  const storyRef = usePrototypeReveal()
  const chapters = [
    [
      thai ? 'คลาสที่มีบริบท' : 'A class with context.',
      thai
        ? 'รู้จักผู้เรียน ชั่วโมงที่เหลือ และรายได้ที่บันทึกแล้ว'
        : 'See the learner, remaining hours, and recorded revenue.',
      <BalancePanel />,
    ],
    [
      thai ? 'วางแผนทั้งวันและสัปดาห์' : 'Plan the day and the week.',
      thai
        ? 'เซสชันเดียวกันอยู่ในมุมมองที่เหมาะกับการตัดสินใจ'
        : 'The same session appears in the view that helps you decide.',
      <div className="paired-panels">
        <DayPanel />
        <WeekPanel />
      </div>,
    ],
    [
      thai ? 'มาถึงอย่างพร้อม' : 'Arrive prepared.',
      thai
        ? 'ยืนยันสิ่งที่เกิดขึ้น แล้วไปต่ออย่างมั่นใจ'
        : 'Confirm what happened, then move ahead with confidence.',
      <TodayPanel />,
    ],
    [
      thai ? 'เก็บบทเรียนที่เสร็จแล้ว' : 'Keep completed lessons close.',
      thai
        ? 'เซสชันที่เสร็จแล้วอยู่ในประวัติของคลาสเดียวกัน'
        : 'A completed session stays in the history of the same class.',
      <TodayPanel completed />,
    ],
  ] as const
  return (
    <div className="prototype-page prototype-a" id="prototype-top">
      <PrototypeHeader />
      <main id="main-content">
        <section
          ref={heroRef}
          className="a-hero prototype-reveal"
          id="product"
          aria-labelledby="a-title"
        >
          <img
            className="a-workspace"
            src={tutorWorkspace}
            alt={
              thai
                ? 'โต๊ะทำงานครูสอนพิเศษในแสงธรรมชาติ'
                : 'Tutor workspace in soft daylight'
            }
          />
          <div className="a-hero-copy">
            <p className="prototype-marker">
              {thai ? 'วันสอนเริ่มต้นอย่างชัดเจน' : 'THE DAY BEGINS CLEAR'}
            </p>
            <h1 id="a-title">
              <span>{thai ? 'วันสอนของคุณ' : 'My teaching day '}</span>
              <span>{thai ? 'อยู่ในการควบคุม' : 'is under control.'}</span>
            </h1>
            <p>
              {thai
                ? 'คลาส ตาราง และสิ่งที่ต้องยืนยัน อยู่ในระยะสายตา'
                : 'Classes, schedules, and the next confirmation stay within sight.'}
            </p>
            <a className="button" href="#workflow">
              {thai ? 'สำรวจ TutorPal' : 'Explore TutorPal'}
            </a>
          </div>
          <div className="a-panel-stack">
            <TodayPanel />
            <BalancePanel compact />
            <WeekPanel />
          </div>
        </section>
        <section className="a-transition">
          <p>
            {thai
              ? 'ก่อนเปิดแท็บต่อไป คุณรู้แล้วว่าวันนี้ต้องให้ความสำคัญกับอะไร'
              : 'Before the next tab opens, you know what deserves your attention.'}
          </p>
        </section>
        <section
          ref={storyRef}
          className="a-story prototype-reveal"
          id="workflow"
        >
          {chapters.map(([title, copy, panel]) => (
            <article key={title} className="a-story-beat">
              <div>
                <h2>{title}</h2>
                <p>{copy}</p>
              </div>
              {panel}
            </article>
          ))}
        </section>
      </main>
      <PrototypeFaq />
      <PrototypeBetaStub />
      <PrototypeFooter />
    </div>
  )
}

function DirectionB() {
  const { thai } = usePrototypeCopy()
  const universeRef = usePrototypeReveal<HTMLDivElement>()

  return (
    <div className="prototype-page prototype-b" id="prototype-top">
      <PrototypeHeader />
      <main id="main-content">
        <section className="b-hero" id="product" aria-labelledby="b-title">
          <div>
            <h1 id="b-title">
              {thai
                ? 'ทุกอย่างสำหรับวันสอนที่ชัดเจนขึ้น'
                : 'Everything for a clearer teaching day.'}
            </h1>
            <p>
              {thai
                ? 'มุมมองที่ทำให้วันสอนเดินหน้า อยู่ใกล้กันพอจะใช้ได้ทันที'
                : 'The views that keep a teaching day moving sit close enough to use when you need them.'}
            </p>
            <a className="button" href="#workflow">
              {thai ? 'สำรวจ TutorPal' : 'Explore TutorPal'}
            </a>
          </div>
          <div
            ref={universeRef}
            className="b-product-universe prototype-reveal"
          >
            <BalancePanel compact />
            <BWeekMaster />
            <TodayPanel />
            <span className="connection connection-one">
              {thai ? 'คลาส' : 'Class'} <i /> {thai ? 'ตาราง' : 'Schedule'}
            </span>
            <span className="connection connection-two">
              {thai ? 'ตาราง' : 'Schedule'} <i /> {thai ? 'วันนี้' : 'Today'}
            </span>
            <img src={tutorObjects} alt="" aria-hidden="true" />
          </div>
        </section>
        <section className="a-transition b-hybrid-transition">
          <p>
            {thai
              ? 'ก่อนเปิดแท็บต่อไป คุณรู้แล้วว่าวันนี้ต้องให้ความสำคัญกับอะไร'
              : 'Before the next tab opens, you know what deserves your attention.'}
          </p>
        </section>
        <section
          className="b-hybrid-story"
          id="workflow"
          aria-label={thai ? 'เส้นทางการสอน' : 'Teaching journey'}
        >
          <BHybridBeat
            index={1}
            title={thai ? 'คลาสที่มีบริบท' : 'A class with context.'}
            copy={
              thai
                ? 'รู้จักผู้เรียน ชั่วโมงที่เหลือ และรายได้ที่บันทึกแล้ว'
                : 'See the learner, remaining hours, and recorded revenue.'
            }
          >
            <BalancePanel />
          </BHybridBeat>
          <BHybridBeat
            index={2}
            title={
              thai ? 'วางแผนทั้งวันและสัปดาห์' : 'Plan the day and the week.'
            }
            copy={
              thai
                ? 'เซสชันเดียวกันอยู่ในมุมมองที่เหมาะกับการตัดสินใจ'
                : 'The same session appears in the view that helps you decide.'
            }
          >
            <div className="paired-panels">
              <DayPanel />
              <BWeekMaster />
            </div>
          </BHybridBeat>
          <BHybridBeat
            index={3}
            title={thai ? 'มาถึงอย่างพร้อม' : 'Arrive prepared.'}
            copy={
              thai
                ? 'ยืนยันสิ่งที่เกิดขึ้น แล้วไปต่ออย่างมั่นใจ'
                : 'Confirm what happened, then move ahead with confidence.'
            }
          >
            <TodayPanel />
          </BHybridBeat>
          <BHybridBeat
            index={4}
            title={
              thai ? 'เก็บบทเรียนที่เสร็จแล้ว' : 'Keep completed lessons close.'
            }
            copy={
              thai
                ? 'เซสชันที่เสร็จแล้วอยู่ในประวัติของคลาสเดียวกัน'
                : 'A completed session stays in the history of the same class.'
            }
          >
            <TodayPanel completed />
          </BHybridBeat>
        </section>
        <section
          className="b-capability-rail"
          id="benefits"
          aria-label={thai ? 'ความสามารถของ TutorPal' : 'TutorPal capabilities'}
        >
          <strong>
            {thai
              ? 'นักเรียน · คลาส · ชั่วโมง · ตาราง · รายได้ · LINE integration'
              : 'Students · Classes · Hours · Schedules · Revenue · LINE integration'}
          </strong>
          <span>
            {thai
              ? 'เชื่อมต่อ LINE Official Account และส่งการแจ้งเตือนคลาสให้กับนักเรียนที่เชื่อมไว้'
              : 'Connect your LINE Official Account and send class reminders to linked students.'}
          </span>
        </section>
      </main>
      <PrototypeFaq />
      <PrototypeBetaStub />
      <PrototypeFooter />
    </div>
  )
}

function DirectionC() {
  const { thai } = usePrototypeCopy()
  const rulerRef = usePrototypeReveal<HTMLDivElement>()
  const acts = [
    [thai ? 'คลาสและชั่วโมง' : 'Class and hours.', <BalancePanel />],
    [thai ? 'ปฏิทินและช่วงเวลา' : 'Calendar and slot.', <WeekPanel />],
    [thai ? 'ยืนยันวันนี้' : 'Confirm Today.', <TodayPanel />],
    [thai ? 'วันที่เชื่อมต่อกัน' : 'A connected day.', <DayPanel />],
  ] as const
  return (
    <div className="prototype-page prototype-c" id="prototype-top">
      <PrototypeHeader />
      <main id="main-content">
        <section className="c-hero" id="product" aria-labelledby="c-title">
          <div>
            <h1 id="c-title">
              {thai
                ? 'จังหวะที่สบายขึ้นสำหรับทุกบทเรียน'
                : 'A calmer rhythm for every lesson.'}
            </h1>
            <p>
              {thai
                ? 'TutorPal เชื่อมงานเล็ก ๆ ของการสอนเข้าด้วยกัน เพื่อให้คุณมีสมาธิกับนักเรียน'
                : 'TutorPal connects the small jobs around teaching, so your attention can stay with the learner.'}
            </p>
            <a className="button button-on-light" href="#workflow">
              {thai ? 'สำรวจ TutorPal' : 'Explore TutorPal'}
            </a>
          </div>
          <div ref={rulerRef} className="c-time-ruler prototype-reveal">
            <WeekPanel ruler />
            <BalancePanel compact />
            <TodayPanel />
          </div>
        </section>
        <section className="c-intro">
          <p>
            {thai
              ? 'สี่จังหวะที่ทำให้วันสอนเดินไปข้างหน้า'
              : 'Four beats that keep a teaching day moving.'}
          </p>
        </section>
        <section className="c-acts" id="workflow">
          {acts.map(([title, panel]) => (
            <article key={title}>
              <h2>{title}</h2>
              {panel}
            </article>
          ))}
        </section>
        <section className="c-band" id="benefits">
          <p>
            {thai
              ? 'นักเรียน · คลาส · ชั่วโมง · ตาราง · รายได้ · LINE'
              : 'Students · Classes · Hours · Schedules · Revenue · LINE'}
          </p>
        </section>
      </main>
      <PrototypeFaq />
      <PrototypeBetaStub />
      <PrototypeFooter />
    </div>
  )
}

function PrototypeSwitcher({
  current,
}: {
  current: CinematicPrototypeVariant
}) {
  const navigate = useNavigate({ from: '/' })
  const { language } = useMarketingLanguage()
  const keys = Object.keys(variants) as CinematicPrototypeVariant[]
  const index = keys.indexOf(current)
  const changeVariant = (offset: number) => {
    const next = keys[(index + offset + keys.length) % keys.length]
    navigate({
      to: '/',
      search: (previous) => ({ ...previous, variant: next }),
      replace: true,
    })
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ? 'auto'
        : 'smooth',
    })
  }
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
      if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey)
        return
      const target = event.target instanceof Element ? event.target : null
      if (
        target?.closest(
          'input, textarea, select, [contenteditable="true"], [role="slider"], [role="spinbutton"], [role="listbox"], [role="menu"], [role="tree"], [role="grid"]',
        )
      )
        return
      event.preventDefault()
      changeVariant(event.key === 'ArrowLeft' ? -1 : 1)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  })
  return (
    <aside
      className="prototype-switcher"
      aria-label={
        language === 'th' ? 'เลือกแนวทางต้นแบบ' : 'Choose prototype direction'
      }
      data-active-variant={current}
      data-language={language}
    >
      <button
        type="button"
        onClick={() => changeVariant(-1)}
        aria-label={language === 'th' ? 'แนวทางก่อนหน้า' : 'Previous direction'}
      >
        ←
      </button>
      <span>
        <strong>{current}</strong>
        <em>{variants[current].name}</em>
      </span>
      <button
        type="button"
        onClick={() => changeVariant(1)}
        aria-label={language === 'th' ? 'แนวทางถัดไป' : 'Next direction'}
      >
        →
      </button>
    </aside>
  )
}

export function CinematicPrototype({
  variant,
}: {
  variant: CinematicPrototypeVariant
}) {
  const { copy } = useMarketingLanguage()
  const contents: Record<CinematicPrototypeVariant, ReactNode> = {
    A: <DirectionA />,
    B: <DirectionB />,
    C: <DirectionC />,
  }
  return (
    <>
      <a className="skip-link" href="#main-content">
        {copy.common.skipToContent}
      </a>
      <div className="cinematic-prototype">{contents[variant]}</div>
      <PrototypeSwitcher current={variant} />
    </>
  )
}
