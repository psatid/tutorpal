# TutorPal marketing frontend

TutorPal’s public, server-rendered marketing site. It is a TanStack Start app
deployed as a Cloudflare Worker, separate from the authenticated product and
its signup behavior.

```bash
bun install
cp .env.example .env
bun run dev
```

The public routes are `/`, `/privacy`, `/robots.txt`, and `/sitemap.xml`. The
beta form posts to the same-origin `/api/beta-interest` Worker route.

## Marketing assets and motion

Authentic product previews live in `public/product-previews/`. Capture the
English TutorPal portal from a clean account with no admin email, test-user
names, fixture classes, or personal data. A small fictional capture dataset is
allowed when it is isolated to the screenshots and clearly reflects the real
portal flow. Keep screenshots static and use them for the hero, product tour,
and social preview. Do not replace them with hand-built fake dashboard markup.

The approved capture set includes `home.jpg`, `schedules.jpg`, `courses.jpg`,
and `classes.jpg` for the hero and supporting product surfaces. The literal
workflow uses the real Classes list followed by five workflow captures:
`classes.jpg`, `workflow-02-add-hours.jpg`, `workflow-03-add-schedule.jpg`,
`workflow-04-schedule-day.jpg`, `workflow-05-schedule-week.jpg`, and
`workflow-06-today-connected.jpg`.
The workflow captures must show the real Classes list, Add hours, Add New
Schedule, Schedules Day, Schedules Week, and Home/Today states. Keep the same
fictional class and session visible across the sequence where the product
allows it. Filter or frame the portal so only the sanitized demo flow is
visible. Never include unrelated workspace records just to make a screen look
fuller. Crop or mask account chrome whenever it exposes a tutor name, email,
avatar, or other identity; the workflow assets must not rely on a runtime
redaction layer.

The home page uses CSS motion and `IntersectionObserver` only. The product tour
uses a preview-led 58/42 desktop composition with compact story intervals and a
header-safe pinned stage. At tablet widths (768px–1119px) the preview stacks before the story
rail so screenshots retain their native proportions. Mobile uses a shorter
preview stage above the current story copy so the app screen stays readable on
a narrow viewport. Every preview reserves the source 822:781 ratio and uses
containment rather than cropping or stretching. On desktop and mobile, as each
row crosses the reading band, `IntersectionObserver` selects the next real
screenshot. The pin is CSS positioning, not a scroll hijack, so the page
remains normally scrollable.
FAQ answers use a native disclosure that opens and closes instantly. English is
the server-rendered default; the header language switcher changes the landing and privacy copy to
Thai, updates the document language, and keeps route anchors and form field
names unchanged. Product screenshots remain English captures from the real
portal. All copy remains available without JavaScript.
Reduced-motion users get the same content without transforms, reveals,
accordion transitions, or screenshot crossfades.

Build the production app with:

```bash
bun run build
bun run test
```

## Deploy to Cloudflare Workers

This project uses the Cloudflare Vite plugin (configured in `vite.config.ts`) and `wrangler.jsonc`.

1. Create a KV namespace and replace `REPLACE_WITH_KV_NAMESPACE_ID` in
   `wrangler.jsonc` with its ID.
2. Set `PUBLIC_SITE_URL` and, if used, `PUBLIC_PORTAL_URL` and
   `PUBLIC_TURNSTILE_SITE_KEY` as public build variables (use `.env` locally
   and provide them to the deployment build). Keep matching non-secret values
   in Worker configuration where the runtime needs them.
3. Set `DISCORD_WEBHOOK_URL` and `TURNSTILE_SECRET_KEY` using `wrangler secret put`.
4. Generate binding types with `bun run cf-typegen`, then deploy with `bun run deploy`.

Without all three integrations (KV, Turnstile secret, and Discord webhook), the
endpoint intentionally returns a clear configuration error rather than a fake
success. Configure the Worker Custom Domain at the apex domain in Cloudflare.

The KV windows are best-effort abuse throttling: Cloudflare KV is eventually
consistent, so concurrent requests can race the five-attempt and 24-hour email
checks. If strict concurrent enforcement is required before production, replace
the KV coordinator with an explicitly approved strongly consistent primitive
such as a Durable Object.

## Cinematic homepage prototypes

These are throwaway design explorations. The selected direction combines B's
hero with A's story and lower sections, at the B URL; A and C remain comparison
references. Start the
marketing app with `bun run dev`, then compare the existing home route:

- `http://localhost:5180/?variant=A` — **The Day Begins Clear**: a daylight
  tutor-workspace scene and a narrative through the teaching day.
- `http://localhost:5180/?variant=B` — **Everything in Reach**: the selected
  hybrid of B's connected product hero and A's class-to-completion story.
- `http://localhost:5180/?variant=C` — **The Teaching Rhythm**: navy-to-light
  pacing through four chapters of preparing and teaching lessons.

The design question is how TutorPal can feel cinematic while retaining its
indigo, navy, cool-white surfaces, recognizable product behavior, and English/Thai
support. Launch awareness is the goal: **Explore TutorPal** leads the story;
beta interest is secondary. The emotional promise is “my teaching day is under
control.”

For this exploration, the user explicitly permits custom product illustrations
instead of requiring actual screenshots. Illustrations must closely represent
the current TutorPal product: Today agenda and session confirmation, Day/Week
scheduling, class membership, remaining/total hours, and the navy class-balance
panel. Layout and motion may emphasize these views, but must not imply invented
features, status values, analytics, or automation. Only sanitized demonstration
content belongs in the public visuals. The running local product was inspected
read-only to ground this direction; its private records and account chrome are
not marketing assets. This prototype-specific decision supersedes the
screenshot-only rule above for these development variants.

One behavior matters when illustrating lesson completion: scheduled time is
already reserved from class hours. Marking the session Completed must not show
the remaining balance decreasing a second time. See
[schedule and hour tracking](../docs/features/schedule-class-hours.md).

Visual references: [WellNest](https://dribbble.com/shots/27361994-WellNest-Website)
for atmospheric product staging,
[Sagitarius](https://dribbble.com/shots/25587153-Sagitarius-Ovulation-Period-Website)
for layered screens,
[Payco](https://dribbble.com/shots/26123217-Payco-SAAS-Website-Design)
for section pacing, and
[ChronoTask](https://dribbble.com/shots/25000009-ChronoTask-Landing-Page) and
[CoreShift](https://dribbble.com/shots/25869450-Sleek-Landing-Page-for-CoreShift)
for spatial composition. Their identities, product imagery, claims, and
testimonials are not reused.

The floating switcher exposes the active concept and supports previous/next
buttons and arrow keys outside editable controls. Its URL can be copied and
reloaded. Prototype routes are development-only; `/` without a valid variant
and production builds keep the existing homepage. Prototype beta forms are
local previews and do not submit information or invoke Turnstile. The existing
production form and endpoint remain separate.
The prototype component, stylesheet, and artwork load through a development-only
import and are excluded from production output.

The hybrid adds a detailed, localized Fri–Sun crop of the real Week layout and
four independent scroll reveals: class balance fill, Day/Week settling, Today
confirmation emphasis, and completed-session emphasis. Panels are readable
before animation; reduced-motion preferences leave them static. The completed
illustration keeps the same reserved-hour balance. LINE integration appears in
the feature rail: tutors connect their own Official Account and send class
reminders to linked students, as documented in
[LINE settings](../docs/features/tutor-line-settings.md) and
[class reminders](../docs/features/line-class-reminders.md).
Local verification covered the build, A/B/C layouts from 320 to 1440 pixels,
English/Thai phone layouts, switching and editable-field keyboard behavior,
FAQ disclosures, and original-route fallbacks. The refined hybrid also passed
English and Thai layout checks at 320, 390, 768, 1024, and 1440 pixels; ordinary
scrolling activated all four chapter effects. Reduced-motion behavior was
checked in source; browser emulation was unavailable.

The user selected B's hero with A's remaining sections on September 7, 2026,
requested greater visual fidelity and scroll motion, and asked to include LINE
integration in the feature list. This approves further prototype refinement;
it does not promote the prototype to production. Work remains local, with no
commits, pushes, or deployment. When production implementation is requested,
preserve the exploration and its verdict following the prototype skill and the
user's Git preferences.

### Atmospheric image provenance

`src/assets/prototype/tutor-workspace.png` was generated with the built-in
image-generation tool for this exploration. It is atmospheric photography,
not a screenshot or evidence of product functionality. The approved real
portal captures and the inspected product guide faithful UI illustrations.

Generation prompt: “Create a horizontal 16:9 natural photographic scene of an
independent tutor's quiet contemporary home workspace in Bangkok in soft early
morning light. Low side angle across an orderly white desk, navy cloth notebook,
indigo pen, glass of water, and partial silver laptop on the right; a sheer
white curtain and softly blurred plant behind. Keep the left half an
uncluttered pale cool-white wall with negative space for navy page copy.
Cinematic shallow depth of field, natural material textures, airy high-key
exposure and soft directional shadows. Cool whites, gentle daylight warmth,
navy and indigo accents. No people, readable text, logos, watermark, displayed
software UI, floating interfaces, or webpage mockup.”

`src/assets/prototype/tutor-objects.png` is supporting 3D artwork created with
the same built-in tool. It depicts an indigo notebook, a blank calendar and a
white clock on white. It represents teaching materials, not an application
screen. Generation prompt: “A refined 3D composition of a white flip-calendar
with indigo header and blank cells, a white analogue clock with navy hands,
and a thin indigo notebook. Satin plastic, paper textures, soft daylight studio
lighting, gentle three-quarter perspective. Compact wide arrangement; no text,
logos, numbers, dashboard, or cartoon effects.” The final edit replaced the
background with solid white while preserving the objects and composition.
